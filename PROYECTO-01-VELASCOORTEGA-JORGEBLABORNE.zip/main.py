from lifestore_file import lifestore_products
#print (lifestore_products)

from lifestore_file import lifestore_sales
#print (lifestore_sales)

from lifestore_file import lifestore_searches
#print (lifestore_searches)

Productos = lifestore_products

#print(Productos)

Ventas = lifestore_sales
#print(Ventas)

Busquedas = lifestore_searches
#print(Busquedas)


listadecon = [["Javier","ELLC"],["Jorge","ELBLABO"]]

usuario = input("Ingresa tu Nombre ")
contraseña = input("Ingresa la contraseña ")

acc = 0
n_veces = 1
 
for u in listadecon :
  if usuario == u[0] and contraseña == u[1]:
    acc = acc + 1



while acc == 1 and n_veces  < 2 :
  
  print("Bienvenido al programa de Jorge Blaborne","\n\n" )

  ######### Busquedas #########
  lista = []
  for i in Productos:
    conta=0
    for k in Busquedas:
      if k[1] == i[0] :
        conta = conta + 1
        
    lista.append(conta)   
  #print(lista)
  lista2 = []
  con = 0
  for y in lista:
    con = con + 1    
    #xd = ("El ID ", con , "Tiene ", y , "Busquedas")
    xd = y , "Busquedas, tiene el articulo  ", con

    lista2.append(xd)

  lp = sorted(lista2, reverse = True)
  lp1 = sorted(lista2, reverse = False)

  print("Los 20 productos más buscados son : ","\n\n")
  print(lp[0:20],"\n\n")
  print("Los 40 productos que no fueron buscados son : ","\n\n")
  print(lp1[0:40],"\n\n")
    


  ############# Ventas #############
  lista3 = []
  for i in Productos:
    conta=0
    for k in Ventas:
      if k[1] == i[0] :
        conta = conta + 1
        
    lista3.append(conta)   

  #print(lista3)
  lista4 = []
  con = 0
  for y in lista3:
    con = con + 1    
    #xd = ("El ID ", con , "Tiene ", y , "Busquedas")
    xd = (y , "Ventas, tiene el articulo", con)

    lista4.append(xd)
   
  lp2 = sorted(lista4, reverse = True)
  lp3 = sorted(lista4, reverse = False)

  print("Los 20 productos más vendidos son : ","\n\n")
  print(lp2[0:20],"\n\n")
  print("Los 54 productos que NO fueron vendidos son : ","\n\n")
  print(lp3[0:54],"\n\n")


  ###### Por Categoría #####

  ### Menores Ventas de categoría de Discos Duros ###
  lista5 = []

  for i in Productos:
    conta=0
    for k in Ventas:
      if k[1] == i[0] and i[3] == "discos duros" :
        conta = conta + 1
        
    lista5.append(conta)   
  #print(lista5)

  lista6 = []
  con = 0
  for y in lista5:
    con = con + 1    
    #xd = ("El ID ", con , "Tiene ", y , "Busquedas")
    xd = (y , "Ventas, tiene el articulo", con)

    lista6.append(xd)

  lp3 = sorted(lista6[46:59], reverse = False)

  print("Las Ventas de la categoría Discos Duros son :""\n\n")
  print(lp3,"\n\n")





  ## Menores Ventas de la categoría Procesadores ###
  lista5 = []

  for i in Productos:
    conta=0
    for k in Ventas:
      if k[1] == i[0] and i[3] == "procesadores" :
        conta = conta + 1
        
    lista5.append(conta)   
  #print(lista5)

  lista6 = []
  con = 0
  for y in lista5:
    con = con + 1    
    #xd = ("El ID ", con , "Tiene ", y , "Busquedas")
    xd = (y , "Ventas, tiene el articulo", con)

    lista6.append(xd)

  lp3 = sorted(lista6[0:9], reverse = False)

  print("Las Ventas de la categoría Procesadores son :""\n\n")
  print(lp3,"\n\n")



  ##### Productos Reseña en el Servicio ###

  lista7 = []

  for i in Productos:
    conta=0
    for k in Ventas:
      if k[1] == i[0] and k[2] == 5 :
        conta = conta + 1
      
    lista7.append(conta)   

  #print(lista7)
  lista8 = []
  con = 0
  for y in lista7:
    con = con + 1    
  #xd = ("El ID ", con , "Tiene ", y , "Busquedas")
    xd = (y , "Calificaciones de 5 tiene el producto ", con)

    lista8.append(xd)

    
  lp3 = sorted(lista8, reverse = True)

  print("Los 20 productos con mejores reseñas son : " ,"\n\n")
  print(lp3[0:20],"\n\n")


  #### Peor Calificación ####
  lista5 = []

  for i in Productos:
    conta=0
    for k in Ventas:
      if k[1] == i[0] and (k[2] == 1 or k[2] == 2 or k[2] == 3) :
        conta = conta + 1
        
    lista5.append(conta)   
  #print(lista5)

  lista6 = []
  con = 0
  for y in lista5:
    con = con + 1    
    #xd = ("El ID ", con , "Tiene ", y , "Busquedas")
    xd = (y , "Opiniones debajo de la media tiene el prodcuto", con)

    lista6.append(xd)

  lp3 = sorted(lista6, reverse = True)

  print("Los 12 productos con PEORES reseñas son :" ,"\n\n")
  print(lp3[0:12],"\n\n")


  ####### Productos devueltos #####
  lista5 = []

  for i in Productos:
    conta=0
    for k in Ventas:
      if k[1] == i[0] and k[4] == 1  :
        conta = conta + 1
        
    lista5.append(conta)   

  #print(lista5)

  lista6 = []
  con = 0
  for y in lista5:
    con = con + 1    
    #xd = ("El ID ", con , "Tiene ", y , "Busquedas")
    xd = (y , "Devoluciones tiene el producto", con)

    lista6.append(xd)

    
  lp3 = sorted(lista6, reverse = True)
  print("Los 7 productos devueltos fueron :" ,"\n\n")
  print(lp3[0:7],"\n\n")






  ###### Punto 3 Ingresos por mes y año  ###
  lista5 = []

  for i in Productos:
    conta=0
    for k in Ventas:
      if k[1] == i[0]  :
        conta = conta + 1
        
    lista5.append(conta)   

  #print(lista5)

  listadePrecios = []
  for i in range(0,96):
    Precios = (Productos [i][2] * lista5 [i] )
    listadePrecios.append(Precios)


  #print(listadePrecios)

  d = sum(listadePrecios)

  print ("Las ventas toales de la tienda fueron: ", d ,"\n\n")
  print("Las ventas totales del año 2020 fueron 759,695 Pesos","\n\n")

  print("Los ingresos totales de la tienda (Ya con devoluciones) fueron: 737,916 Pesos" ,"\n\n")
  print("Las ventas totales del año 2020 fueron 759,695 Pesos")

  print("Las ventas totales del año 2002 fueron 300 Pesos")
  print("Las ventas totales del año 2019 fueron 182 Pesos","\n\n")

  ####### Ventas por Mes ###
  lista5 = []
  fechas = []

  for i in Productos:
    conta=0
    for k in Ventas:
    
      if k[1] == i[0]  :
        conta = conta + 1
        fechas.append(k[3])  
    lista5.append(conta)   
  #print(lista5)
  #print(fechas)
  lista_años = []
  for año in fechas:
    lista_años.append ((año[3:5], int(año[6:10])))
  #print(lista_años)
  listaorda = sorted(lista_años, reverse = False)

  #print(listaorda)
  conta = 0
  for k in listaorda:
    if k [0] == "01" :
      conta = conta + 1
      #print(conta)

  print("Hubo", conta, "Ventas en Enero","\n\n")

  conta = 0
  for k in listaorda:
    if k [0] == "02" :
      conta = conta + 1
      #print(conta)

  print("Hubo", conta, "Ventas en Febrero","\n\n")


  conta = 0
  for k in listaorda:
    if k [0] == "03" :
      conta = conta + 1
      #print(conta)

  print("Hubo", conta, "Ventas en Marzo","\n\n")

  conta = 0
  for k in listaorda:
    if k [0] == "04" :
      conta = conta + 1
      #print(conta)

  print("Hubo", conta, "Ventas en Abril","\n\n")

  conta = 0
  for k in listaorda:
    if k [0] == "05" :
      conta = conta + 1
      #print(conta)

  print("Hubo", conta, "Ventas en Mayo","\n\n")

  conta = 0
  for k in listaorda:
    if k [0] == "06" :
      conta = conta + 1
      #print(conta)

  print("Hubo", conta, "Ventas en Junio","\n\n")

  conta = 0
  for k in listaorda:
    if k [0] == "07" :
      conta = conta + 1
      #print(conta)

  print("Hubo", conta, "Ventas en Julio","\n\n")

  conta = 0
  for k in listaorda:
    if k [0] == "08" :
      conta = conta + 1
      #print(conta)

  print("Hubo", conta, "Ventas en Agosto","\n\n")


  conta = 0
  for k in listaorda:
    if k [0] == "09" :
      conta = conta + 1
      #print(conta)

  print("Hubo", conta, "Venta en Septiembre","\n\n")

  conta = 0
  for k in listaorda:
    if k [0] == "11" :
      conta = conta + 1
      #print(conta)

  print("Hubo", conta, "Venta en Noviembre de 2019","\n\n")

  n_veces += 1

  print("SI Llegaste hasta aquí omite el siguiente mensaje")

print("Contraseña Incorrecta, vuelve a correr el programa cuadno te acuerdes de la contraseña por favor")    


